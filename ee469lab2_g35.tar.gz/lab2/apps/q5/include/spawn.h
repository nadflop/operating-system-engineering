#ifndef _spawn_h_
#define _spawn_h_

#define INJECT_H2O "inject_h2o.dlx.obj"
#define INJECT_SO4 "inject_so4.dlx.obj"
#define REACTION_1 "reaction1.dlx.obj"
#define REACTION_2 "reaction2.dlx.obj"
#define REACTION_3 "reaction3.dlx.obj"

#endif
