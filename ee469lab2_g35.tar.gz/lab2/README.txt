how to build solution
  cd os
  make
  cd ../apps/q?
  make
  
anything unusual that the TA should know
  No
  
list of any external sources referenced while working on your solution
  None
